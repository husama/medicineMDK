CREATE FUNCTION `getChildLst`(`rootId` INT(11))
  RETURNS VARCHAR(1000)
BEGIN
	DECLARE sTemp VARCHAR(1000);  
	DECLARE sTempChd VARCHAR(1000);  
	  
	SET sTemp = '$';  
	SET sTempChd =cast(rootId as CHAR);  
	WHILE sTempChd is not null DO  
		SET sTemp = concat(sTemp,',',sTempChd);  
		SELECT group_concat(spq_id) INTO sTempChd 
        FROM supplement_question
        where FIND_IN_SET(spq_fk,sTempChd)>0;  
	END WHILE;  
	RETURN sTemp;  
END