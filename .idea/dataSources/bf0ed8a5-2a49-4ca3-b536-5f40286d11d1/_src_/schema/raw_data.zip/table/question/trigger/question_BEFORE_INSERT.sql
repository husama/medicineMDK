CREATE TRIGGER `question_BEFORE_INSERT`
BEFORE INSERT ON `question`
FOR EACH ROW
  BEGIN
	if new.isadopt !=0 and new.isadopt!=1 then
		SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = 'isadopt值不对 sb' ;
	end if;
END