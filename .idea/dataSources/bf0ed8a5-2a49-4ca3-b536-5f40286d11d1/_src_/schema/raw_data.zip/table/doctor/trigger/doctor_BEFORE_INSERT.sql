CREATE TRIGGER `doctor_BEFORE_INSERT`
BEFORE INSERT ON `doctor`
FOR EACH ROW
  BEGIN
	if (new.adoptrate <0 or new.adoptrate>100) and new.adoptrate is not null then
		SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = 'adoptrate值不对 sb' ;
	end if;
    if (new.satisfatdegree <0 or new.satisfatdegree>100) and new.adoptrate is not null then
		SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = 'satisfatdegree值不对 sb' ;
	end if;
END