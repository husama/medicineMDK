CREATE TRIGGER `ask_BEFORE_INSERT`
BEFORE INSERT ON `ask`
FOR EACH ROW
  BEGIN
	IF NEW.sex !='男' AND NEW.sex !='女' and new.sex is not null THEN
             SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = 'sex值不对 sb' ;
	end if;
    IF NEW.age >100 or NEW.age<0 and new.age is not null THEN
             SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = 'age值不对 sb' ;
	end if;
END