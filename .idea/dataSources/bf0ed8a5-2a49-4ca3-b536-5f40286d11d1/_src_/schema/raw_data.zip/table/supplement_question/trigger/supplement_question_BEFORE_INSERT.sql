CREATE TRIGGER `supplement_question_BEFORE_INSERT`
BEFORE INSERT ON `supplement_question`
FOR EACH ROW
  BEGIN
	IF NEW.sign !=0 AND NEW.sign !=1 THEN
             SIGNAL SQLSTATE 'HY000' SET MESSAGE_TEXT = 'sign值不对 sb' ;
	end if;
END